require 'spec_helper'

describe ReservationsController do

end
