require 'spec_helper'

describe StaticPagesController do

end
